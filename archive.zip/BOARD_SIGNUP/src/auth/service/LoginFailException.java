package auth.service;

// 아이디와 암호가 잘못된 경우
// LoginFailException을 발생시킨다.
public class LoginFailException extends RuntimeException{

}
