package member.service;

// 암호를 변경할 회원 데이터가 존재하지 않는 경우 발생하는 예외 처리 클래스 작성
public class MemberNotFoundException extends RuntimeException {

}
